from django.contrib.auth.models import User
import django_filters
from django.http import JsonResponse, HttpResponse
from .models import Album
from django_filters import filters
from filters.views import FilterMixin
from . import views
import music.views
from django.shortcuts import get_object_or_404

UZYTKOWNICY_LISTA = User.objects.all().order_by('username').values_list("id","username").distinct()
UZYTKOWNICY = list(UZYTKOWNICY_LISTA)
UZYTKOWNICY.insert(0, ('0','---------') )
UZYTKOWNICY.pop(4)

ZDARZENIA_LISTA = Album.objects.all().order_by('aktywnosc').values_list("aktywnosc","aktywnosc").distinct()
ZDARZENIA_FILTR = list(ZDARZENIA_LISTA)
ZDARZENIA_FILTR.insert(0, ('','---------') )


MIASTA = Album.objects.all().order_by('miejscowosc').values_list("miejscowosc","miejscowosc").distinct()
MIASTALISTA = list(MIASTA)
MIASTAPELNALISTA = MIASTALISTA.insert(0, ('0','---------') )

KODY = Album.objects.all().values_list("kodpocztowy","kodpocztowy").distinct()


TERMINY = Album.objects.all().values_list("termin","termin").distinct()
# IMPORTOWANA = music.views.ZMIENNAGLOBALNA
# INNEMIASTA = Album.objects.filter(aktywnosc='Urlop').values_list('miejscowosc', 'miejscowosc').distinct()

baza =[]
user_baza = User.objects.all().order_by('username')

def dynamiczne_filtrowanie(request):

    ajax_aktywnosc = request.GET.get('aktywnosc', False)
    ajax_user = request.GET.get('user', False)
    print ("To jest user ktory przyszedł %s." % ajax_user)
    print (type(ajax_user))

    global baza
    global user_baza
    global uzytkownik
    print (ajax_aktywnosc)

    # if ajax_user == "user=":
    #     print ('jestem false')
    # else:
    #     print('nie jestm false')
    user_dane = ajax_user.split('&')
    user_baza = []

    for x in user_dane:
        y = x.split('=')[1]
        if y=="0":
            user = User.objects.all()
            print(user)
            user_baza = []
            # for a in user:
            #     user_baza.append(a.id)
            #     print (a.id)
            # print("To jest tymczasowa user baza %s." % user_baza)
        else:
            user_baza.append(int(y))

    print ("To jest glowna user baza %s." % user_baza)



    #     if y=="":
    #         user = User.objects.all()
    #         print(user)
    #         user_baza = []
    #         for a in user:
    #             user_baza.append(a.id)
    #             print (a.id)
    #         return (user_baza)
    #     else:
    #         user_baza.append(int(y))




    # if ajax_user != "user=":
    #     user_dane = ajax_user.split('&')
    #     user_baza = []
    #     for x in user_dane:
    #         y = x.split('=')[1]
    #         user_baza.append(int(y))
    # else:
    #     user = User.objects.all()
    #     user_baza = []
    #     for x in user:
    #         user_baza.append(x.id)




    if ajax_aktywnosc != False:
        dane = ajax_aktywnosc.split("&")
        baza =[]
        for x in dane:
            x = x.replace("+", " ")
            baza.append(x.split('=')[1])
        print(x)
        print (baza)
        return(baza)

    # return JsonResponse(dane, safe=False)
    return HttpResponse(baza, user_baza)






class UserFilter(django_filters.FilterSet):
    # product_choices = {
    #     '': ('---------', ''),
    #     'fresh': ('Fresh', { 'method': 'age_group', 'args': ('fresh', ), }),
    #     'regular': ('Regular', {'method': 'age_group', 'args': ('regular', ), }),
    #     'old': ('Old', {'method': 'age_group', 'args': ('old', ), }),}
    aktywnosc = django_filters.MultipleChoiceFilter(choices=ZDARZENIA_FILTR)
    miejscowosc = django_filters.MultipleChoiceFilter(choices=MIASTAPELNALISTA)
    # miejscowosc = django_filters.ModelMultipleChoiceFilter(queryset=Album.objects.all().values_list('miejscowosc').distinct())
    # miejscowosc = QuerySetFilter(product_choices, label='Product age choices')
    kodpocztowy = django_filters.MultipleChoiceFilter(choices=KODY)
    termin = django_filters.DateFromToRangeFilter()
    user = django_filters.MultipleChoiceFilter(choices=UZYTKOWNICY)

    class Meta:
        model = Album
        fields = ['aktywnosc', 'miejscowosc', 'kodpocztowy', 'termin', 'user']

    # def __init__(self, *args, **kwargs):
    #     super(UserFilter, self).__init__(*args, **kwargs)

    def __init__(self, *args, **kwargs):
        print('to jest init')
        super(UserFilter, self).__init__(*args, **kwargs)
        print("to jest baza %s." % baza)
        print("baza uzytkownikow %s." % user_baza)
        aktywnosci_temp = []
        for x in user_baza:
            x = Album.objects.filter(user_id=x).values_list('aktywnosc', 'aktywnosc').distinct()
            aktywnosci_temp.extend(x)
        # if aktywnosci == []:
            # self.filters['aktywnosc'].extra.update(
            # {
            # 'choices': Album.ZDARZENIA
            # })
        # else:
        aktywnosci = list(set(aktywnosci_temp))
        aktywnosci.insert(0, ('','---------') )
        print("aktywnosci w inicie %s." % aktywnosci)
        if user_baza == []:
            self.filters['aktywnosc'].extra.update(
            {
            'choices': sorted(ZDARZENIA_FILTR)
            })
        else:
            self.filters['aktywnosc'].extra.update(
            {
            'choices': sorted(aktywnosci)
            })

        cities = []
        cities.insert(0, ('','---------') )
        for x in user_baza:
            x = Album.objects.filter(user_id=x).values_list('miejscowosc', 'miejscowosc').distinct()
            cities.extend(x)
        # print ("to są miasta %s." % cities)
        codes = []
        for x in user_baza:
            x = Album.objects.filter(user_id=x).values_list('kodpocztowy', 'kodpocztowy').distinct()
            codes.extend(x)
            print (codes)
        if cities == []:
            self.filters['kodpocztowy'].extra.update(
            {
            'choices': KODY
            })
        else:
            self.filters['kodpocztowy'].extra.update(
            {
            'choices': codes
            })


        if cities == []:
            self.filters['miejscowosc'].extra.update(
            {
                'choices': sorted(MIASTALISTA)
            })
        else:
            self.filters['miejscowosc'].extra.update(
            {
                'choices': sorted(cities)
            })
            # print(Album.objects.filter(aktywnosc=baza[0]).values_list('miejscowosc', 'miejscowosc').distinct())
        # INNEMIASTA = Album.objects.filter(aktywnosc='Wizyta').values_list('miejscowosc', 'miejscowosc').distinct()
        # miejscowosc = django_filters.MultipleChoiceFilter(choices=INNEMIASTA)
        # return(miejscowosc)
        # print(MIASTA)
        # print(miastab)
    #     # cos['aktywnosc'].choices = Album.objects.all().values_list("miejscowosc","miejscowosc").distinct()
    #     # print(choices)
    #
    #     for name, field in self.filters.items():
    #         if isinstance(field, django_filters.ChoiceFilter):
    #             # Add "Any" entry to choice fields.
    #             field.extra['choices'] = tuple([("", "Any"), ] + list(field.extra['choices']))
